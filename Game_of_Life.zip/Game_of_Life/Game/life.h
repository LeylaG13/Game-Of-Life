
void initialize(int **array, int rows, int columns);

void random_alive(int **array, int rows, int columns);